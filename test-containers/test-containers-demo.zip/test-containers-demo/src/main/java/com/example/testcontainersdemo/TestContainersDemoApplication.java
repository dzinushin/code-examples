package com.example.testcontainersdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestContainersDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestContainersDemoApplication.class, args);
	}

}
