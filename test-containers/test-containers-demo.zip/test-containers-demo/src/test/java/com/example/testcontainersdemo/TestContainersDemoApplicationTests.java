package com.example.testcontainersdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestContainersDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
